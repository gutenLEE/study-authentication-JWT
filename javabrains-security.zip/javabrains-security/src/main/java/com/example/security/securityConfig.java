package com.example.security;

import org.springframework.context.annotation.Bean;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

@EnableWebSecurity // tell spring security that this is a web security config
public class securityConfig extends WebSecurityConfigurerAdapter {
    @Override
    protected void configure(AuthenticationManagerBuilder auth) throws Exception {
        // have opportunity do whatever i want here
        // set my configuration to this auth argument

        // 1. set the type of authentication that we need
        // 2. based on that we provide the inputs
        // 3. take this auth object
        auth.inMemoryAuthentication()
                .withUser("blah")
                .password("blah")
                .roles("USER")
                .and()
                .withUser("foo")
                .password("foo")
                .roles("ADMIN");
    }

    @Bean
    public PasswordEncoder setPasswordEncoder() {
        return NoOpPasswordEncoder.getInstance();
    }


    // authoriztion
    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.authorizeRequests()
                // this is where you specify the mapping of path to role
                // this method lets me configure what the path should be
                .antMatchers("/", "static/css", "static/js").permitAll()
                .antMatchers("/admin").hasRole("ADMIN")
                .antMatchers("/user").hasAnyRole("USER", "ADMIN")
                // all URLs need to be accessible only by someone who has the user role
                .and().formLogin();
    }
}
